from msilib.schema import Media

import os

dirname = './media/photo/'
os.chmod(dirname, 0o755)